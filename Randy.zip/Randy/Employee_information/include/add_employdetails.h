#ifndef ADD_EMPLOYDETAILS_H
#define ADD_EMPLOYDETAILS_H

#include <QDialog>
#include <QDialog>
#include <QtSql>
#include <QSqlDatabase>
#include <QFileInfo>

namespace Ui {
class add_employdetails;
}

class add_employdetails : public QDialog
{
    Q_OBJECT

public:
     QSqlDatabase sqlitedb;

    void connClose()
    {
        sqlitedb.close();
        sqlitedb.removeDatabase(QSqlDatabase::defaultConnection);
    }
    bool connOpen(){
        sqlitedb = QSqlDatabase::addDatabase("QSQLITE");
       sqlitedb.setDatabaseName("C:/Users/C PC/Desktop/Randy/Employee_information/assets/employeedb.sqlite");
       if(!sqlitedb.open()){
          qDebug()<<("Failed to open databsae");
          return false;
       }
       else{
           qDebug()<<("Connected........");
           return true;
       }
    }

public:
    explicit add_employdetails(QWidget *parent = nullptr);
    ~add_employdetails();

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::add_employdetails *ui;
};

#endif // ADD_EMPLOYDETAILS_H

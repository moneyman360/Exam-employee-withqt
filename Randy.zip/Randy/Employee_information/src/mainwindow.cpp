#include "include\mainwindow.h"
#include "ui_mainwindow.h"
#include"include\add_employdetails.h"
#include"include\edit_employdetails.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    hide();
  add_employdetails add_employdetails;
  add_employdetails.setModal(true);
  add_employdetails.exec();
}


void MainWindow::on_pushButton_2_clicked()
{
    hide();
  edit_employdetails edit_employdetails;
  edit_employdetails.setModal(true);
  edit_employdetails.exec();
}


#include "include\edit_employdetails.h"
#include "ui_edit_employdetails.h"
#include "include\mainwindow.h"
#include "include\add_employdetails.h"
#include <QMessageBox>


edit_employdetails::edit_employdetails(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::edit_employdetails)
{
    ui->setupUi(this);

    add_employdetails conn;
   if(!conn.connOpen()){
      ui->label_6->setText("Failed to open databsae");
   }
   else{
       ui->label_6->setText("Connected........");
   }
}

edit_employdetails::~edit_employdetails()
{
    delete ui;
}

void edit_employdetails::on_pushButton_4_clicked()
{
    this->close();

    MainWindow* mainWin = new MainWindow();
    mainWin->setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    mainWin->show();
}


void edit_employdetails::on_pushButton_clicked()
{
    add_employdetails conn;
    QSqlQueryModel * modal = new QSqlQueryModel();


    if(!conn.connOpen()){
        qDebug()<<"Failed to open the database";
        return;
    }
    else{
          QSqlQuery*qry =new QSqlQuery(conn.sqlitedb);
          qry->prepare("select * from employeeInfo ");
          qry->exec();

          modal->setQuery(*qry);
          ui->tableView->setModel(modal);
          if(qry->exec())
          {

              conn.connClose();
              qDebug()<<(modal->rowCount());
          }
          else{
              QMessageBox::critical(this,tr("error"),qry->lastError().text());
          }



        }
}


void edit_employdetails::on_pushButton_2_clicked()
{
    add_employdetails conn;
   QString EID,Name,Age,Phone_number;
   EID=ui->lineEdit->text();
   Name=ui->lineEdit_4->text();
   Age=ui->lineEdit_2->text();
   Phone_number=ui->lineEdit_3->text();

   if(!conn.connOpen()){
       qDebug()<<"Failed to open the database";
       return;
   }
   else{
       QSqlQuery qry;
        qry.prepare("update employeeInfo  set EID='"+EID+"',Name='"+Name+"',Age='"+Age+"',Phone_number='"+Phone_number+"'where EID='"+EID+"' ");
       if(qry.exec())
       {
           QMessageBox::critical(this,tr("Edit"),tr("Data is updated"));
           conn.connClose();
       }
       else{
           QMessageBox::critical(this,tr("error"),qry.lastError().text());
       }

       }

}


void edit_employdetails::on_pushButton_3_clicked()
{
    add_employdetails conn;
   QString EID,Name,Age,Phone_number;
   EID=ui->lineEdit->text();

   if(!conn.connOpen()){
       qDebug()<<"Failed to open the database";
       return;
   }
   else{
       QSqlQuery qry;
        qry.prepare("delete from employeeInfo where EID='"+EID+"'");
       if(qry.exec())
       {
           QMessageBox::critical(this,tr("Delete"),tr("Deleted"));
           conn.connClose();
       }
       else{
           QMessageBox::critical(this,tr("error"),qry.lastError().text());
       }

       }
}


#include "include\add_employdetails.h"
#include "ui_add_employdetails.h"
#include "include\mainwindow.h"
#include <QMessageBox>

add_employdetails::add_employdetails(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::add_employdetails)
{
    ui->setupUi(this);
    if(!connOpen()){
       ui->label_6->setText("Failed to open databsae");
    }
    else{
        ui->label_6->setText("Connected........");
    }
}

add_employdetails::~add_employdetails()
{
    delete ui;
}

void add_employdetails::on_pushButton_3_clicked()
{
    this->close();

    MainWindow* mainWin = new MainWindow();
    mainWin->setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    mainWin->show();
}


void add_employdetails::on_pushButton_clicked()
{
    QString EID,Name,Age,Phone_number;
   EID=ui->lineEdit->text();
    Name=ui->lineEdit_2->text();
    Age=ui->lineEdit_3->text();
    Phone_number=ui->lineEdit_4->text();


    if(!connOpen()){
        qDebug()<<"Failed to open the database";
        return;
    }
    else{
         connOpen();
        QSqlQuery qry;
         qry.prepare("insert into employeeInfo (EID,Name,Age, Phone_number) values('"+EID+"','"+Name+"','"+Age+"','"+Phone_number+"')");

         if(qry.exec())
        {
            QMessageBox::critical(this,tr("Saved"),tr("Data is saved"));
            connClose();
        }
        else{
            QMessageBox::critical(this,tr("error"),qry.lastError().text());
        }

        }
}


void add_employdetails::on_pushButton_2_clicked()
{
    connOpen();
    QSqlQueryModel * modal = new QSqlQueryModel();


    if(!connOpen()){
        qDebug()<<"Failed to open the database";
        return;
    }
    else{
          QSqlQuery*qry =new QSqlQuery(sqlitedb);
          qry->prepare("select * from employeeInfo ");
          qry->exec();

          modal->setQuery(*qry);
          ui->tableView->setModel(modal);
          if(qry->exec())
          {

              connClose();
              qDebug()<<(modal->rowCount());
          }
          else{
              QMessageBox::critical(this,tr("error"),qry->lastError().text());
          }



        }
}


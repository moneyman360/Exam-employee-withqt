/********************************************************************************
** Form generated from reading UI file 'edit_employdetails.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDIT_EMPLOYDETAILS_H
#define UI_EDIT_EMPLOYDETAILS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_edit_employdetails
{
public:
    QLabel *label;
    QTableView *tableView;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;

    void setupUi(QDialog *edit_employdetails)
    {
        if (edit_employdetails->objectName().isEmpty())
            edit_employdetails->setObjectName(QString::fromUtf8("edit_employdetails"));
        edit_employdetails->resize(604, 300);
        label = new QLabel(edit_employdetails);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 601, 291));
        label->setStyleSheet(QString::fromUtf8("#label{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:black;\n"
"selection-background-color: darkgray;\n"
"}"));
        tableView = new QTableView(edit_employdetails);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(20, 11, 561, 111));
        pushButton = new QPushButton(edit_employdetails);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(40, 250, 75, 23));
        pushButton_2 = new QPushButton(edit_employdetails);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(180, 250, 75, 23));
        pushButton_3 = new QPushButton(edit_employdetails);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(340, 250, 75, 23));
        pushButton_4 = new QPushButton(edit_employdetails);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(490, 250, 75, 23));
        lineEdit = new QLineEdit(edit_employdetails);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(100, 150, 113, 20));
        lineEdit_2 = new QLineEdit(edit_employdetails);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(100, 200, 113, 20));
        lineEdit_3 = new QLineEdit(edit_employdetails);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(460, 160, 113, 20));
        lineEdit_4 = new QLineEdit(edit_employdetails);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(460, 200, 113, 20));
        label_2 = new QLabel(edit_employdetails);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 150, 61, 16));
        label_2->setStyleSheet(QString::fromUtf8("#label_2{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:skyblue;\n"
"selection-background-color: darkgray;\n"
"}"));
        label_3 = new QLabel(edit_employdetails);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 200, 51, 16));
        label_3->setStyleSheet(QString::fromUtf8("#label_3{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:skyblue;\n"
"selection-background-color: darkgray;\n"
"}"));
        label_4 = new QLabel(edit_employdetails);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(340, 160, 101, 16));
        label_4->setStyleSheet(QString::fromUtf8("#label_4{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:skyblue;\n"
"selection-background-color: darkgray;\n"
"}"));
        label_5 = new QLabel(edit_employdetails);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(340, 200, 101, 16));
        label_5->setStyleSheet(QString::fromUtf8("#label_5{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:skyblue;\n"
"selection-background-color: darkgray;\n"
"}"));
        label_6 = new QLabel(edit_employdetails);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 270, 47, 13));

        retranslateUi(edit_employdetails);

        QMetaObject::connectSlotsByName(edit_employdetails);
    } // setupUi

    void retranslateUi(QDialog *edit_employdetails)
    {
        edit_employdetails->setWindowTitle(QApplication::translate("edit_employdetails", "Dialog", nullptr));
        label->setText(QString());
        pushButton->setText(QApplication::translate("edit_employdetails", "Load", nullptr));
        pushButton_2->setText(QApplication::translate("edit_employdetails", "update", nullptr));
        pushButton_3->setText(QApplication::translate("edit_employdetails", "Delete", nullptr));
        pushButton_4->setText(QApplication::translate("edit_employdetails", "Back", nullptr));
        label_2->setText(QApplication::translate("edit_employdetails", "EID", nullptr));
        label_3->setText(QApplication::translate("edit_employdetails", "Name", nullptr));
        label_4->setText(QApplication::translate("edit_employdetails", "Age", nullptr));
        label_5->setText(QApplication::translate("edit_employdetails", "Phone_number", nullptr));
        label_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class edit_employdetails: public Ui_edit_employdetails {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDIT_EMPLOYDETAILS_H

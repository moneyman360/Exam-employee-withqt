/********************************************************************************
** Form generated from reading UI file 'add_employdetails.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADD_EMPLOYDETAILS_H
#define UI_ADD_EMPLOYDETAILS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_add_employdetails
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QTableView *tableView;
    QLabel *label_6;

    void setupUi(QDialog *add_employdetails)
    {
        if (add_employdetails->objectName().isEmpty())
            add_employdetails->setObjectName(QString::fromUtf8("add_employdetails"));
        add_employdetails->resize(573, 300);
        label = new QLabel(add_employdetails);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(-20, 0, 581, 311));
        label->setStyleSheet(QString::fromUtf8("#label{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:black;\n"
"selection-background-color: darkgray;\n"
"}"));
        label_2 = new QLabel(add_employdetails);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 170, 71, 16));
        label_2->setStyleSheet(QString::fromUtf8("#label_2{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:white;\n"
"selection-background-color: darkgray;\n"
"}"));
        label_3 = new QLabel(add_employdetails);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 210, 71, 16));
        label_3->setStyleSheet(QString::fromUtf8("#label_3{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:white;\n"
"selection-background-color: darkgray;\n"
"}"));
        label_4 = new QLabel(add_employdetails);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(280, 170, 81, 16));
        label_4->setStyleSheet(QString::fromUtf8("#label_4{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:white;\n"
"selection-background-color: darkgray;\n"
"}"));
        label_5 = new QLabel(add_employdetails);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(270, 210, 101, 16));
        label_5->setStyleSheet(QString::fromUtf8("#label_5{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:white;\n"
"selection-background-color: darkgray;\n"
"}"));
        lineEdit = new QLineEdit(add_employdetails);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(100, 170, 141, 20));
        lineEdit_2 = new QLineEdit(add_employdetails);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(100, 210, 141, 20));
        lineEdit_3 = new QLineEdit(add_employdetails);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(400, 170, 141, 20));
        lineEdit_4 = new QLineEdit(add_employdetails);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(390, 210, 141, 20));
        pushButton = new QPushButton(add_employdetails);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(80, 260, 75, 23));
        pushButton->setStyleSheet(QString::fromUtf8("#pushButton{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:skyblue;\n"
"selection-background-color: darkgray;\n"
"}"));
        pushButton_2 = new QPushButton(add_employdetails);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(230, 260, 75, 23));
        pushButton_2->setStyleSheet(QString::fromUtf8("#pushButton_2{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:green;\n"
"selection-background-color: darkgray;\n"
"}"));
        pushButton_3 = new QPushButton(add_employdetails);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(400, 260, 75, 23));
        pushButton_3->setStyleSheet(QString::fromUtf8("#pushButton_3{\n"
"border: 2px solid gray;\n"
"border-radius: 10px;\n"
"padding: 0 8px;\n"
"background:red;\n"
"selection-background-color: darkgray;\n"
"}"));
        tableView = new QTableView(add_employdetails);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 10, 531, 131));
        label_6 = new QLabel(add_employdetails);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(0, 280, 47, 13));

        retranslateUi(add_employdetails);

        QMetaObject::connectSlotsByName(add_employdetails);
    } // setupUi

    void retranslateUi(QDialog *add_employdetails)
    {
        add_employdetails->setWindowTitle(QApplication::translate("add_employdetails", "Dialog", nullptr));
        label->setText(QString());
        label_2->setText(QApplication::translate("add_employdetails", "EID", nullptr));
        label_3->setText(QApplication::translate("add_employdetails", "Name", nullptr));
        label_4->setText(QApplication::translate("add_employdetails", "Age", nullptr));
        label_5->setText(QApplication::translate("add_employdetails", "Phone_number", nullptr));
        pushButton->setText(QApplication::translate("add_employdetails", "Add", nullptr));
        pushButton_2->setText(QApplication::translate("add_employdetails", "Update", nullptr));
        pushButton_3->setText(QApplication::translate("add_employdetails", "Back", nullptr));
        label_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class add_employdetails: public Ui_add_employdetails {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADD_EMPLOYDETAILS_H

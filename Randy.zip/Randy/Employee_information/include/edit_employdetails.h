#ifndef EDIT_EMPLOYDETAILS_H
#define EDIT_EMPLOYDETAILS_H

#include <QDialog>

namespace Ui {
class edit_employdetails;
}

class edit_employdetails : public QDialog
{
    Q_OBJECT

public:
    explicit edit_employdetails(QWidget *parent = nullptr);
    ~edit_employdetails();

private slots:
    void on_pushButton_4_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::edit_employdetails *ui;
};

#endif // EDIT_EMPLOYDETAILS_H
